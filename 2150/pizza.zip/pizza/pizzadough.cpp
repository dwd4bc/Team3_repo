#include <iostream>
using namespace std;
#include "pizzadough.h"

PizzaDough::PizzaDough(int amount)
{
    quantity=amount;
}
